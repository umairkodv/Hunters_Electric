<div class="max-w-7xl mx-auto px-6 sm:px-12 w-full my-6">
    <hr class="border-t-2 border-gray-300/40 w-full" />
</div>